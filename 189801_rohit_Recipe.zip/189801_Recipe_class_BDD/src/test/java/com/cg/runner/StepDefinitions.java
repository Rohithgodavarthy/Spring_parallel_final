package com.cg.runner;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitions {
	
	WebDriver driver;
	@Before
	public void init() {
		 System.setProperty("webdriver.chrome.driver", "D:\\rohit tranning material\\BDD\\BDD Jar files\\chromedriver_win32\\chromedriver.exe");
		
		driver= new ChromeDriver();
	}
	
	@Given("^customer is in recipe class enquiry form page$")
	public void customer_is_in_recipe_class_enquiry_form_page() throws Throwable {
		 driver.get("C:\\Users\\capgemini\\Desktop\\htmlFiles\\Receipe Registration Case study\\Recipe_class_registration.html");
	}

	@Then("^title should be present on the page$")
	public void title_should_be_present_on_the_page() throws Throwable {
		String pagesource= driver.getPageSource();
		   assertTrue(pagesource.contains("<title>"));
		   driver.close();
	}
	
	@Then("^thereshould be text online cooking school$")
	public void thereshould_be_text_online_cooking_school() throws Throwable {
		String pagesource= driver.getPageSource();
		  assertTrue(pagesource.contains("Online Cooking School"));
		   driver.close();
	
	}
	
	@Then("^click on the hyperlink$")
	public void click_on_the_hyperlink() throws Throwable {
		WebElement hyperlink = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td/a"));
		hyperlink.click();
		driver.close();
	}
	@Given("^customer is in msg page$")
	public void customer_is_in_msg_page() throws Throwable {
		driver.get("C:\\Users\\capgemini\\Desktop\\htmlFiles\\Receipe Registration Case study\\Recipe_class_registration.html");
	}


	
	@Then("^there should be text recipe class brochure is sent to your registered mail id$")
	public void there_should_be_text_recipe_class_brochure_is_sent_to_your_registered_mail_id() throws Throwable {
		String pagesource= driver.getPageSource();
		assertTrue(pagesource.contains("Recipe class Brochure is sent to your registered mail id"));
		driver.close();
	
	 
	}

	@When("^user clicks on the go Back to Registration link$")
	public void user_clicks_on_the_go_Back_to_Registration_link() throws Throwable {
		WebElement hyperlink = driver.findElement(By.xpath("/html/body/p/a"));
		hyperlink.click();
	}

	@Then("^it should navigate to recipe page$")
	public void it_should_navigate_to_recipe_page() throws Throwable {
	   
	}
	@Then("^enter first name$")
	public void enter_first_name() throws Throwable {
		WebElement firstNameElement= driver.findElement(By.name("fname"));
		firstNameElement.sendKeys("Rohit");
		driver.close();
	}

	@When("^no data entered in the first name textbox$")
	public void no_data_entered_in_the_first_name_textbox() throws Throwable {
		WebElement firstNameElement= driver.findElement(By.xpath("//*[@id=\"fname\"]"));
		firstNameElement.click();
		WebElement btn = driver.findElement(By.id("Submit1"));
		btn.click();
	}

	@Then("^alert message shouls be displayed$")
	public void alert_message_shouls_be_displayed() throws Throwable {
	     String alertmsg = driver.switchTo().alert().getText();
	     assertEquals(alertmsg, "First Name must be filled out");
	 	driver.close();
	}

	@Then("^enter last name$")
	public void enter_last_name() throws Throwable {
		WebElement firstNameElement= driver.findElement(By.name("lname"));
		firstNameElement.sendKeys("Rohit");
		driver.close();
	    
	}

	@When("^no data entered in the last name textbox$")
	public void no_data_entered_in_the_last_name_textbox() throws Throwable {
		WebElement lastNameElement= driver.findElement(By.xpath("//*[@id=\"lname\"]"));
		lastNameElement.click();
		WebElement btn = driver.findElement(By.id("Submit1"));
		btn.click();
	}
	
	@When("^customer clicks enquiry now button$")
	public void customer_clicks_enquiry_now_button() throws Throwable {
		WebElement btn = driver.findElement(By.id("Submit1"));
		btn.click();
	 
	}
	
	@Then("^enqiry alert message should be displayed$")
	public void enqiry_alert_message_should_be_displayed() throws Throwable {
		String alertmsg = driver.switchTo().alert().getText();
	     assertEquals(alertmsg, "Enquiry details must be filled out");
	 	driver.close();
	}

	@When("^customer enters enquiry text and clicks enquiry now button$")
	public void customer_enters_enquiry_text_and_clicks_enquiry_now_button() throws Throwable {
		WebElement enquiryElement= driver.findElement(By.name("enqdetails"));
		enquiryElement.sendKeys("something");
		WebElement btn = driver.findElement(By.id("Submit1"));
		btn.click();
	}

	@Then("^success alert message should be displayed$")
	public void success_alert_message_should_be_displayed() throws Throwable {
		String alertmsg = driver.switchTo().alert().getText();
	     assertEquals(alertmsg, "Thank you for submitting the online recipe class Enquiry");
	 	driver.close();
	}
	
	@Then("^lastname alert message should be displayed$")
	public void lastname_alert_message_should_be_displayed() throws Throwable {
		String alertmsg = driver.switchTo().alert().getText();
	     assertEquals(alertmsg, "Last Name must be filled out");
	 	driver.close();
	}

	@When("^customer enters enquiry text and clicks enquiry now button and accepts the alert$")
	public void customer_enters_enquiry_text_and_clicks_enquiry_now_button_and_accepts_the_alert() throws Throwable {
		WebElement enquiryElement= driver.findElement(By.name("enqdetails"));
		enquiryElement.sendKeys("something");
		WebElement btn = driver.findElement(By.id("Submit1"));
		btn.click();
		driver.switchTo().alert().accept();
		
	}

	@Then("^there should be a text our location represenattive will contact you soon$")
	public void there_should_be_a_text_our_location_represenattive_will_contact_you_soon() throws Throwable {
		String pagesource= driver.getPageSource();
		assertTrue(pagesource.contains("Our location representative will contact you soon."));
		driver.close();
	}

	
	





}
