package com.cg.pagemodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class RecipePage {
	public RecipePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	WebElement tagname;
	public String getTagname(String tagname) {
			return null;
	}
}
